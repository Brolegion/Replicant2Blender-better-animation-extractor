# cmf_import.py
import bpy
import os
import sys
from io import BytesIO

# Добавляем путь к парсерам
package_path = os.path.dirname(os.path.dirname(__file__))
if package_path not in sys.path:
    sys.path.insert(0, package_path)


from . import motionAssets_import

def main(filepath, addon_name, parsed_cmfs):
    """Основная функция для импорта чистых CMF файлов"""
    print(f"Importing CMF file: {filepath}")
    
    try:
        # Читаем CMF файл
        with open(filepath, 'rb') as f:
            cmf_data = f.read()
        
        # Парсим CMF
        stream = BytesIO(cmf_data)
        cmf = CMF(stream)
        
        # Добавляем действие в глобальное хранилище
        add_cmf_action(cmf, parsed_cmfs)
        
        print(f"Successfully imported CMF: {cmf.name}")
        return True
    except Exception as e:
        print(f"Error importing CMF file {filepath}: {str(e)}")
        import traceback
        traceback.print_exc()
        return False