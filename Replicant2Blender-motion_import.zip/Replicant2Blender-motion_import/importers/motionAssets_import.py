from mathutils import Quaternion, Vector, Matrix
import bpy
import math
import sys
import os



def add_cmf_action(cmf, parsed_cmfs=None):
    if not cmf or not hasattr(cmf, 'name'):
        return

    # Remove existing action if it exists
    if cmf.name in bpy.data.actions:
        bpy.data.actions.remove(bpy.data.actions[cmf.name])

    # Create new action (empty - will be filled when applied)
    action = bpy.data.actions.new(cmf.name)
    action.use_fake_user = True

    # Store CMF for later application
    if parsed_cmfs is not None:
        parsed_cmfs[cmf.name] = cmf

    print(f"✓ Motion prepared: {cmf.name}")

def get_cmfFiles(pack):
    if hasattr(pack, 'cmfFiles'):
        return pack.cmfFiles
    # Для совместимости, но теперь используй pack.cmfFiles
    
    # Совместимость со старым кодом
    cmfFiles = []
    for assetFile in pack.assetFiles:
        if hasattr(assetFile, 'content') and assetFile.content:
            # Проверяем KPK контейнеры
            if hasattr(assetFile.content, 'magic') and assetFile.content.magic == b"KPK\x7F":
                if hasattr(assetFile.content, 'files'):
                    for file in assetFile.content.files:
                        if (file and hasattr(file, 'magic') and 
                            file.magic in [b"CMF\x01", b"CMF\x02", b"CMF\x03"]):
                            cmfFiles.append(file)
            # Проверяем прямые CMF файлы
            elif (hasattr(assetFile.content, 'magic') and 
                  assetFile.content.magic in [b"CMF\x01", b"CMF\x02", b"CMF\x03"]):
                cmfFiles.append(assetFile.content)
    
    return cmfFiles

# ... остальные функции остаются без изменений ...

def game_to_blender_quaternion(game_quat):
    return Quaternion((game_quat[0], game_quat[1], game_quat[2], game_quat[3])).normalized()

def game_to_blender_position(game_pos):
    return Vector((game_pos[0], game_pos[1], game_pos[2]))

def apply_48_axis_remap(vector, axis_remap_x='+X', axis_remap_y='+Y', axis_remap_z='+Z'):
    """
    Применяет ремаппинг осей к вектору (поддерживает все 48 вариантов).
    Возвращает новый вектор после преобразования.
    """
    # Словарь для преобразования компонент
    component_map = {
        '+X': (1, 0, 0),   # Берем X компоненту с положительным знаком
        '-X': (-1, 0, 0),  # Берем X компоненту с отрицательным знаком
        '+Y': (0, 1, 0),   # Берем Y компоненту с положительным знаком
        '-Y': (0, -1, 0),  # Берем Y компоненту с отрицательным знаком
        '+Z': (0, 0, 1),   # Берем Z компоненту с положительным знаком
        '-Z': (0, 0, -1),  # Берем Z компоненту с отрицательным знаком
    }
    
    # Получаем преобразования для каждой оси
    x_map = component_map[axis_remap_x]
    y_map = component_map[axis_remap_y]
    z_map = component_map[axis_remap_z]
    
    # Вычисляем новые компоненты
    new_x = vector.x * x_map[0] + vector.y * x_map[1] + vector.z * x_map[2]
    new_y = vector.x * y_map[0] + vector.y * y_map[1] + vector.z * y_map[2]
    new_z = vector.x * z_map[0] + vector.y * z_map[1] + vector.z * z_map[2]
    
    return Vector((new_x, new_y, new_z))
    
    
def apply_48_axis_remap_to_quaternion(quat, axis_remap_x='+X', axis_remap_y='+Y', axis_remap_z='+Z'):
    """
    Применяет ремаппинг осей к кватерниону (поддерживает все 48 вариантов).
    """
    # Создаем матрицу ремаппинга
    component_map = {
        '+X': (1, 0, 0, 0),
        '-X': (-1, 0, 0, 0),
        '+Y': (0, 1, 0, 0),
        '-Y': (0, -1, 0, 0),
        '+Z': (0, 0, 1, 0),
        '-Z': (0, 0, -1, 0),
    }
    
    # Получаем векторы для новых осей
    new_x = component_map[axis_remap_x]
    new_y = component_map[axis_remap_y]
    new_z = component_map[axis_remap_z]
    
    # Создаем матрицу 3x3 для ремаппинга
    remap_matrix = Matrix((
        (new_x[0], new_y[0], new_z[0]),
        (new_x[1], new_y[1], new_z[1]),
        (new_x[2], new_y[2], new_z[2])
    ))
    
    # Преобразуем кватернион в матрицу 3x3
    rot_matrix = quat.to_matrix()
    
    # Применяем ремаппинг: M' = R * M * R^T
    # где R - матрица ремаппинга, M - матрица вращения
    new_matrix = remap_matrix @ rot_matrix @ remap_matrix.transposed()
    
    return new_matrix.to_quaternion()


# В motionAssets_import.py добавляем/обновляем следующие функции:

def import_motions(pack, parsed_cmfs=None):
    cmfFiles = get_cmfFiles(pack)

    for cmf in cmfFiles:
        add_cmf_action(cmf, parsed_cmfs)

    print(f"Imported {len(cmfFiles)} animations")
    armature = bpy.context.active_object
    
    if armature and armature.type != 'ARMATURE':
        raise Exception("Active object is not an armature")

    for cmf in cmfFiles:
        if not cmf or not hasattr(cmf, 'name'):
            continue
            
        print(f"IMPORTING MOTION: {cmf.name}")

        # Remove existing action if it exists
        if cmf.name in bpy.data.actions:
            bpy.data.actions.remove(bpy.data.actions[cmf.name])

        # Create new action (empty - will be filled when applied)
        action = bpy.data.actions.new(cmf.name)
        action.use_fake_user = True
        
        # Store CMF for later application
        if parsed_cmfs is not None:
            parsed_cmfs[cmf.name] = cmf

        print(f"✓ Motion prepared: {cmf.name}")

def apply_mapped_animation(armature, action_name, parsed_cmfs, transformation_mode='ABSOLUTE'):
    if action_name not in parsed_cmfs:
        print(f"Action {action_name} not found in parsed_cmfs")
        return

    cmf = parsed_cmfs[action_name]

    if action_name not in bpy.data.actions:
        print(f"Action {action_name} not found in bpy.data.actions")
        return

    action = bpy.data.actions[action_name]

    if not armature.animation_data:
        armature.animation_data_create()
    armature.animation_data.action = action

    # Clear existing keyframes
    action.fcurves.clear()

    # Reset pose to rest pose
    bpy.ops.pose.select_all(action='SELECT')
    bpy.ops.pose.transforms_clear()
    bpy.context.view_layer.update()

    # Create mapping from CMF indices to pose bones
    index_to_bone = {}
    for mapping in getattr(armature.data, "motion_mappings", []):
        if getattr(mapping, "bone_name", None) and mapping.bone_name in armature.pose.bones:
            index_to_bone[mapping.cmf_index] = armature.pose.bones[mapping.bone_name]

    package_path = os.path.dirname(__file__)
    if package_path not in sys.path:
        sys.path.insert(0, package_path)
    
    # Получаем имя аддона из пути
    addon_name = __name__.split('.')[0] if '.' in __name__ else __name__
    prefs = bpy.context.preferences.addons.get(addon_name).preferences
    
    if prefs:
        axis_remap_x = prefs.anim_axis_remap_x
        axis_remap_y = prefs.anim_axis_remap_y
        axis_remap_z = prefs.anim_axis_remap_z
    else:
        # Значения по умолчанию
        axis_remap_x = '+X'
        axis_remap_y = '+Y'
        axis_remap_z = '+Z'
    
    # ЛОГИРОВАНИЕ: Начало применения анимации
    print(f"\n=== APPLYING ANIMATION: {action_name} ===")
    print(f"Transformation mode: {transformation_mode}")
    print(f"Axis remap: X->{axis_remap_x}, Y->{axis_remap_y}, Z->{axis_remap_z}")
    print(f"Total bones in CMF: {cmf.boneCount}")
    print(f"Total frames in CMF: {cmf.framesCount}")
    
    # Логируем информацию о N_ALL/root кости (индекс 0)
    if cmf.framesTransData1 and len(cmf.framesTransData1.transformations) > 0:
        transData1_root = cmf.framesTransData1.transformations[0]
        if transData1_root:
            print(f"\nN_ALL/root (index 0) rotation frames: {transData1_root.frameCount}")
            # Ищем третий кадр (индекс 2, так как индексы начинаются с 0)
            for frame_idx, value in zip(transData1_root.indices, transData1_root.values):
                if frame_idx == 2:  # Третий кадр
                    print(f"  Frame 3 rotation data: {value}")
                    break
    
    if cmf.framesTransData2 and len(cmf.framesTransData2.transformations) > 0:
        transData2_root = cmf.framesTransData2.transformations[0]
        if transData2_root:
            print(f"N_ALL/root (index 0) location frames: {transData2_root.frameCount}")
            for frame_idx, value in zip(transData2_root.indices, transData2_root.values):
                if frame_idx == 2:  # Третий кадр
                    print(f"  Frame 3 location data: {value}")
                    break
    
    # Применяем анимацию с настройками осей
    for i in sorted(index_to_bone.keys()):  # Sort to apply from root to children
        transData1 = cmf.framesTransData1.transformations[i] if i < len(cmf.framesTransData1.transformations) else None
        transData2 = cmf.framesTransData2.transformations[i] if i < len(cmf.framesTransData2.transformations) else None
        
        poseBone = index_to_bone[i]
        restBone = armature.data.bones[poseBone.name]
        poseBone.rotation_mode = 'QUATERNION'

        # Get rest transforms in local space
        rest_matrix = restBone.matrix_local
        if restBone.parent:
            parent_rest_matrix = restBone.parent.matrix_local
            rest_matrix_local = parent_rest_matrix.inverted() @ rest_matrix
        else:
            rest_matrix_local = rest_matrix

        rest_rot = rest_matrix_local.to_quaternion().normalized()
        rest_pos = rest_matrix_local.to_translation()
        
        # ЛОГИРОВАНИЕ: Информация о кости
        bone_logged = False

        # Rotations
        if transData1:
            for frame_index, value in zip(transData1.indices, transData1.values):
                rot_value = [value[3], value[0], value[1], value[2]]
                anim_rot = game_to_blender_quaternion(rot_value).normalized()
                
                # Применяем ремаппинг осей к вращению
                anim_rot = apply_48_axis_remap_to_quaternion(
                    anim_rot, 
                    axis_remap_x, 
                    axis_remap_y, 
                    axis_remap_z
                )
                
                # ЛОГИРОВАНИЕ: Только для третьего кадра
                if frame_index == 2 and not bone_logged:
                    print(f"\n=== BONE: {poseBone.name} (index {i}) ===")
                    print(f"Parent: {restBone.parent.name if restBone.parent else 'None'}")
                    print(f"Rest rotation (local): {rest_rot}")
                    print(f"Rest position (local): {rest_pos}")
                    print(f"Rest matrix (local):")
                    for row in rest_matrix_local:
                        print(f"  [{', '.join([f'{x:.6f}' for x in row])}]")
                    print(f"CMF rotation input (w,x,y,z order): {rot_value}")
                    print(f"Blender rotation after axis remap: {anim_rot}")
                    bone_logged = True
                
                # Вычисляем delta_rot в зависимости от режима
                if transformation_mode == 'RELATIVE':
                    delta_rot = anim_rot
                elif transformation_mode == 'ABSOLUTE_INVERTED':
                    delta_rot = anim_rot @ rest_rot.inverted()
                elif transformation_mode == 'RELATIVE_INVERTED':
                    delta_rot = rest_rot.inverted() @ anim_rot
                elif transformation_mode == 'WORLD_SPACE':
                    world_rot = anim_rot
                    parent_world_rot = armature.pose.bones[restBone.parent.name].rotation_quaternion if restBone.parent else Quaternion((1,0,0,0))
                    delta_rot = parent_world_rot.inverted() @ world_rot
                elif transformation_mode == 'DIRECT':
                    delta_rot = anim_rot
                elif transformation_mode == 'RELATIVE_ROT_ABS_POS':
                    delta_rot = anim_rot
                elif transformation_mode == 'ABS_ROT_REL_POS':
                    delta_rot = rest_rot.inverted() @ anim_rot
                elif transformation_mode == 'INVERTED_ANIM_ROT':
                    delta_rot = anim_rot.inverted()
                elif transformation_mode == 'AXIS_SWAP_ROT':
                    anim_rot_swapped = Quaternion((anim_rot.w, anim_rot.y, anim_rot.x, anim_rot.z))
                    delta_rot = rest_rot.inverted() @ anim_rot_swapped
                elif transformation_mode == 'NORMALIZED_DELTA':
                    delta_rot = (rest_rot.inverted() @ anim_rot).normalized()
                elif transformation_mode == 'PARENT_ADJUSTED':
                    if restBone.parent:
                        parent_rest_rot = armature.data.bones[restBone.parent.name].matrix_local.to_quaternion().normalized()
                        delta_rot = parent_rest_rot @ (rest_rot.inverted() @ anim_rot)
                    else:
                        delta_rot = rest_rot.inverted() @ anim_rot
                elif transformation_mode == 'DELTA_INVERTED':
                    delta_rot = (rest_rot.inverted() @ anim_rot).inverted()
                elif transformation_mode == 'GAME_AXIS_ADJUST':
                    adjust_quat = Quaternion((0.7071067811865476, 0.7071067811865475, 0, 0))  # 90 deg X
                    delta_rot = adjust_quat @ anim_rot @ adjust_quat.inverted()
                    delta_rot = rest_rot.inverted() @ delta_rot
                elif transformation_mode == 'REST_MULTIPLIED':
                    delta_rot = rest_rot @ anim_rot
                elif transformation_mode == 'ANIM_REST_MULTIPLIED':
                    delta_rot = anim_rot @ rest_rot
                elif transformation_mode == 'INVERTED_BOTH':
                    delta_rot = (rest_rot.inverted() @ anim_rot).inverted()
                elif transformation_mode == 'CONJUGATED_ANIM':
                    delta_rot = anim_rot.conjugated() @ rest_rot
                elif transformation_mode == 'ABSOLUTE_ORIGINAL':
                    delta_rot = rest_rot.inverted() @ anim_rot
                elif transformation_mode == 'RELATIVE_AXIS_REMAPPED':
                    adjust_quat = Quaternion((0.7071, 0.7071, 0, 0))  # 90 deg X
                    delta_rot = adjust_quat @ anim_rot @ adjust_quat.inverted()
                else:  # ABSOLUTE (default, with normalization)
                    delta_rot = rest_rot.inverted() @ anim_rot
                
                # ЛОГИРОВАНИЕ: Только для третьего кадра
                if frame_index == 2:
                    print(f"Frame 3 - Final rotation (delta_rot): {delta_rot}")
                    print(f"Frame 3 - Applied to pose bone")
                
                poseBone.rotation_quaternion = delta_rot.normalized()
                poseBone.keyframe_insert(data_path="rotation_quaternion", frame=frame_index)

        # Positions
        if transData2:
            for frame_index, value in zip(transData2.indices, transData2.values):
                # Проверяем, нужно ли отключать локацию для этой кости
                disable_location = False
                if hasattr(armature.data, "disable_location_enabled") and armature.data.disable_location_enabled:
                    start_idx = getattr(armature.data, "disable_location_start", 0)
                    end_idx = getattr(armature.data, "disable_location_end", 0)
                    if start_idx <= i <= end_idx:
                        disable_location = True
                
                if not disable_location:
                    anim_pos = game_to_blender_position(value)
                    # Применяем ремаппинг осей к позиции
                    anim_pos = apply_48_axis_remap(
                        anim_pos, 
                        axis_remap_x, 
                        axis_remap_y, 
                        axis_remap_z
                    )
                    
                    # ЛОГИРОВАНИЕ: Только для третьего кадра
                    if frame_index == 2 and not bone_logged:
                        print(f"\n=== BONE: {poseBone.name} (index {i}) ===")
                        print(f"Parent: {restBone.parent.name if restBone.parent else 'None'}")
                        print(f"Rest rotation (local): {rest_rot}")
                        print(f"Rest position (local): {rest_pos}")
                        print(f"Rest matrix (local):")
                        for row in rest_matrix_local:
                            print(f"  [{', '.join([f'{x:.6f}' for x in row])}]")
                        print(f"CMF position input: {value}")
                        print(f"Blender position after axis remap: {anim_pos}")
                        bone_logged = True
                    
                    # Вычисляем delta_pos в зависимости от режима
                    if transformation_mode == 'RELATIVE':
                        delta_pos = anim_pos
                    elif transformation_mode == 'ABSOLUTE_INVERTED':
                        delta_pos = rest_pos - anim_pos
                    elif transformation_mode == 'RELATIVE_INVERTED':
                        delta_pos = -anim_pos
                    elif transformation_mode == 'WORLD_SPACE':
                        world_pos = Matrix.Translation(anim_pos)
                        parent_world_matrix = armature.pose.bones[restBone.parent.name].matrix if restBone.parent else Matrix.Identity(4)
                        delta_matrix = parent_world_matrix.inverted() @ world_pos
                        delta_pos = delta_matrix.to_translation()
                    elif transformation_mode == 'DIRECT':
                        delta_pos = anim_pos
                    elif transformation_mode == 'RELATIVE_ROT_ABS_POS':
                        delta_pos = anim_pos - rest_pos
                    elif transformation_mode == 'ABS_ROT_REL_POS':
                        delta_pos = anim_pos
                    elif transformation_mode == 'INVERTED_ANIM_ROT':
                        delta_pos = -anim_pos
                    elif transformation_mode == 'AXIS_SWAP_ROT':
                        anim_pos_swapped = Vector((-anim_pos.y, -anim_pos.x, anim_pos.z))
                        delta_pos = anim_pos_swapped - rest_pos
                    elif transformation_mode == 'NORMALIZED_DELTA':
                        delta_pos = anim_pos - rest_pos
                    elif transformation_mode == 'PARENT_ADJUSTED':
                        if restBone.parent:
                            parent_rest_pos = armature.data.bones[restBone.parent.name].matrix_local.to_translation()
                            delta_pos = anim_pos - parent_rest_pos
                        else:
                            delta_pos = anim_pos - rest_pos
                    elif transformation_mode == 'DELTA_INVERTED':
                        delta_pos = -(anim_pos - rest_pos)
                    elif transformation_mode == 'GAME_AXIS_ADJUST':
                        adjust_matrix = Matrix.Rotation(math.radians(90), 4, 'X')
                        anim_pos_adjusted = adjust_matrix @ anim_pos
                        delta_pos = anim_pos_adjusted - rest_pos
                    elif transformation_mode == 'REST_MULTIPLIED':
                        delta_pos = rest_pos + anim_pos
                    elif transformation_mode == 'ANIM_REST_MULTIPLIED':
                        delta_pos = anim_pos + rest_pos
                    elif transformation_mode == 'INVERTED_BOTH':
                        delta_pos = -(anim_pos - rest_pos)
                    elif transformation_mode == 'CONJUGATED_ANIM':
                        delta_pos = -anim_pos
                    elif transformation_mode == 'ABSOLUTE_ORIGINAL':
                        delta_pos = anim_pos - rest_pos
                    elif transformation_mode == 'RELATIVE_AXIS_REMAPPED':
                        delta_pos = Vector((anim_pos.x, anim_pos.z, -anim_pos.y))
                    else:  # ABSOLUTE (default)
                        delta_world = anim_pos - rest_pos
                        bone_rest_rotation = rest_matrix_local.to_quaternion()
                        delta_pos = bone_rest_rotation.inverted() @ delta_world
                    
                    # ЛОГИРОВАНИЕ: Только для третьего кадра
                    if frame_index == 2:
                        print(f"Frame 3 - Final position (delta_pos): {delta_pos}")
                        print(f"Frame 3 - Applied to pose bone")
                    
                    poseBone.location = delta_pos
                    poseBone.keyframe_insert(data_path="location", frame=frame_index)
                else:
                    # Если локация отключена, устанавливаем позицию в rest_pos (нулевую локальную позицию)
                    poseBone.location = Vector((0, 0, 0))
                    poseBone.keyframe_insert(data_path="location", frame=frame_index)

        bpy.context.view_layer.update()  # Update after each bone to handle dependencies

    print(f"\n✓ Applied animation with mapping: {action_name} (mode: {transformation_mode})")

def transfer_n_all_to_armature(armature, action_name, parsed_cmfs):
    """
    Переносит анимацию с кости N_ALL/root на арматуру, даже если кости N_ALL нет в скелете.
    Автоматически определяется по индексу 0 в анимации.
    """
    if action_name not in parsed_cmfs:
        print(f"Action {action_name} not found in parsed_cmfs")
        return

    cmf = parsed_cmfs[action_name]
    if action_name not in bpy.data.actions:
        print(f"Action {action_name} not found in bpy.data.actions")
        return

    print(f"Transferring N_ALL animation to armature: {action_name}")

    # Проверяем есть ли кость 0 (N_ALL/root) в анимации
    has_root_rotation = False
    has_root_location = False
    
    # ROTATIONS - кость 0
    if (hasattr(cmf, 'framesTransData1') and cmf.framesTransData1 and 
        len(cmf.framesTransData1.transformations) > 0 and 
        cmf.framesTransData1.transformations[0] is not None):
        has_root_rotation = True
        transData = cmf.framesTransData1.transformations[0]
        print(f"Found root rotation data: {len(transData.indices)} frames")
        
        # Применяем rotation к арматуре
        for frame_index, value in zip(transData.indices, transData.values):
            if len(value) >= 4:
                cmf_quat_in = (value[0], value[1], value[2], value[3])
                # Конвертируем в Blender кватернион (w,x,y,z)
                quat_blender = Quaternion((value[3], value[0], value[1], value[2])).normalized()
                
                armature.rotation_mode = 'QUATERNION'
                armature.rotation_quaternion = quat_blender
                armature.keyframe_insert(data_path="rotation_quaternion", frame=frame_index)
    
    # LOCATIONS - кость 0  
    if (hasattr(cmf, 'framesTransData2') and cmf.framesTransData2 and 
        len(cmf.framesTransData2.transformations) > 0 and 
        cmf.framesTransData2.transformations[0] is not None):
        has_root_location = True
        transData = cmf.framesTransData2.transformations[0]
        print(f"Found root location data: {len(transData.indices)} frames")
        
        # Применяем location к арматуру
        for frame_index, value in zip(transData.indices, transData.values):
            if len(value) >= 3:
                cmf_loc = Vector((value[0], value[1], value[2]))
                # Стандартная трансформация для локаций
                transformed_loc = Vector((-cmf_loc.y, -cmf_loc.x, cmf_loc.z))
                
                armature.location = transformed_loc
                armature.keyframe_insert(data_path="location", frame=frame_index)

    if not has_root_rotation and not has_root_location:
        print("No root bone (index 0) animation found in CMF")
        return
        
    print("Successfully transferred root animation to armature")
    
def extract_bone_names_from_mdvl(filepath):
    """
    Извлекает имена костей из MDVL файлов, правильно парся CJF структуру.
    """
    try:
        with open(filepath, 'rb') as f:
            data = f.read()
        
        print(f"Чтение файла: {filepath}, размер: {len(data)} байт")
        
        # Ищем CJF блок
        cjf_start = data.find(b'CJF\x01')
        if cjf_start == -1:
            print("CJF блок не найден")
            return []
        
        print(f"Найден CJF блок на позиции 0x{cjf_start:08X}")
        
        # Парсим структуру CJF
        bone_names = parse_cjf_structure(data, cjf_start)
        
        if not bone_names:
            # Если не нашли через структуру, используем эвристический метод
            bone_names = extract_bone_names_heuristic(data, cjf_start)
        
        print(f"\n=== ИМЕНА КОСТЕЙ ИЗ CJF ({len(bone_names)}) ===")
        for i, name in enumerate(bone_names):
            print(f"{i:3d}: {name}")
        
        return bone_names
        
    except Exception as e:
        print(f"Ошибка при извлечении имён костей: {e}")
        import traceback
        traceback.print_exc()
        return []


def parse_cjf_structure(data, cjf_start):
    """Парсит структуру CJF для извлечения имён костей в правильном порядке."""
    pos = cjf_start
    bone_names = []
    
    try:
        # Пропускаем сигнатуру CJF\x01
        pos += 4
        
        # Читаем количество костей (2 или 4 байта?)
        # В разных версиях CJF структура может отличаться
        # Пробуем прочитать как 2-байтное целое
        if pos + 2 > len(data):
            return []
        
        bone_count = int.from_bytes(data[pos:pos+2], 'little')
        pos += 2
        
        print(f"Количество костей в CJF: {bone_count}")
        
        # Пропускаем возможные дополнительные байты
        # Ищем начало таблицы имён (обычно это смещение от начала CJF)
        # Пробуем найти последовательность имён костей
        
        # Ограничим область поиска
        search_end = min(len(data), cjf_start + 0x1000)
        
        # Ищем N_ALL (обычно первая кость)
        n_all_pos = data.find(b'N_ALL\x00', pos, search_end)
        if n_all_pos == -1:
            print("Не найдена кость N_ALL")
            return []
        
        print(f"Найдена N_ALL на позиции 0x{n_all_pos:08X}")
        
        # Начинаем чтение имён с этой позиции
        current_pos = n_all_pos
        max_bones = min(bone_count * 3, 500)  # Защита от бесконечного цикла
        
        while len(bone_names) < max_bones and current_pos < search_end:
            # Пропускаем нулевые байты
            if data[current_pos] == 0:
                current_pos += 1
                continue
            
            # Начало строки
            start = current_pos
            
            # Читаем до нулевого байта
            while current_pos < search_end and data[current_pos] != 0:
                current_pos += 1
            
            if current_pos > start:
                try:
                    bone_name = data[start:current_pos].decode('ascii', errors='ignore')
                    
                    # Проверяем, что это имя кости
                    if is_valid_bone_name(bone_name) and bone_name not in bone_names:
                        bone_names.append(bone_name)
                        
                        # Если собрали все кости, выходим
                        if len(bone_names) >= bone_count:
                            break
                except:
                    pass
            
            current_pos += 1
        
        return bone_names
        
    except Exception as e:
        print(f"Ошибка при парсинге CJF структуры: {e}")
        return []


def extract_bone_names_heuristic(data, cjf_start):
    """Эвристический метод извлечения имён костей."""
    bone_names = []
    
    # Определяем область поиска (обычно имена находятся в пределах 2KB после CJF)
    search_start = cjf_start
    search_end = min(len(data), cjf_start + 0x2000)
    
    print(f"Эвристический поиск в диапазоне 0x{search_start:08X}-0x{search_end:08X}")
    
    # Сначала находим все строки в этой области
    strings = []
    current_pos = search_start
    
    while current_pos < search_end:
        # Пропускаем не-ASCII (значения > 127) и нулевые байты
        byte_val = data[current_pos]
        if byte_val == 0 or byte_val > 127:
            current_pos += 1
            continue
        
        # Начало строки
        start = current_pos
        
        # Читаем последовательность ASCII символов (32-126)
        while current_pos < search_end and 32 <= data[current_pos] <= 126:
            current_pos += 1
        
        # Если строка достаточно длинная и содержит буквы
        str_len = current_pos - start
        if str_len >= 3 and str_len <= 100:
            try:
                string = data[start:current_pos].decode('ascii')
                if any(c.isalpha() for c in string):
                    strings.append(string)
            except:
                pass
        
        current_pos += 1
    
    print(f"Найдено {len(strings)} строк в области CJF")
    
    # Фильтруем строки, оставляя только те, что похожи на имена костей
    for string in strings:
        if is_likely_bone_name(string) and string not in bone_names:
            bone_names.append(string)
    
    # Пробуем найти упорядоченную последовательность
    ordered_names = find_ordered_bone_sequence(bone_names, data, search_start, search_end)
    
    if ordered_names and len(ordered_names) > 10:
        return ordered_names
    
    return bone_names


def is_likely_bone_name(name):
    """Проверяет, похоже ли имя на имя кости (менее строгая версия)."""
    if not name or len(name) < 2 or len(name) > 100:
        return False
    
    # Должна содержать буквы
    if not any(c.isalpha() for c in name):
        return False
    
    # Фильтруем очевидный мусор
    lower_name = name.lower()
    
    bad_patterns = [
        'mesh', 'tex', 'mat', 'shader', 'texture', 'material',
        'error', 'null', 'none', 'void', 'empty', '0x', '\\x',
        'cjf', 'kpk', 'cmf', 'pack', 'header'
    ]
    
    if any(bad in lower_name for bad in bad_patterns):
        return False
    
    # Проверяем паттерны имён костей
    bone_patterns = [
        'left', 'right', 'l_', 'r_',
        'arm', 'leg', 'hand', 'foot', 'finger',
        'thumb', 'index', 'middle', 'ring', 'pinky',
        'hip', 'shoulder', 'elbow', 'knee', 'wrist', 'ankle',
        'spine', 'neck', 'head', 'eye', 'toe',
        'back', 'waist', 'fore', 'up', 'low',
        'bone', 'as_', 'tubomi', 'sphere',
        'all', 'root', 'master', 'control'
    ]
    
    # Если содержит любой из паттернов - скорее всего кость
    if any(pattern in lower_name for pattern in bone_patterns):
        return True
    
    # Содержит подчёркивания и заглавные буквы
    if '_' in name and any(c.isupper() for c in name):
        return True
    
    # CamelCase с цифрами на конце (например, TUBOMI_A1)
    if any(c.isdigit() for c in name[-2:]) and any(c.isupper() for c in name):
        return True
    
    return False


def find_ordered_bone_sequence(bone_names, data, search_start, search_end):
    """Пытается найти упорядоченную последовательность имён костей."""
    if not bone_names:
        return []
    
    # Создаём словарь позиций имён в файле
    name_positions = []
    for name in bone_names:
        # Ищем имя как строку с нулевым байтом на конце
        name_bytes = name.encode('ascii') + b'\x00'
        pos = data.find(name_bytes, search_start, search_end)
        if pos != -1:
            name_positions.append((pos, name))
    
    # Сортируем по позиции
    name_positions.sort(key=lambda x: x[0])
    
    # Проверяем, что позиции идут последовательно (примерно)
    ordered_names = []
    for pos, name in name_positions:
        ordered_names.append(name)
    
    # Если нашли достаточное количество упорядоченных имён
    if len(ordered_names) > 10:
        # Проверяем, что имена имеют логическую последовательность
        # (например, начинаются с N_ALL, затем LEFT/RIGHT группы)
        has_n_all = any('n_all' in name.lower() for name in ordered_names[:5])
        has_left_right = any('left' in name.lower() for name in ordered_names) and \
                        any('right' in name.lower() for name in ordered_names)
        
        if has_n_all and has_left_right:
            print(f"Найдена упорядоченная последовательность из {len(ordered_names)} имён")
            return ordered_names
    
    return []


# Функция для создания маппинга (с улучшенной логикой)
def create_bone_mapping_from_cjf(armature, cjf_bones, armature_bones):
    """Создаёт маппинг на основе порядка имён из CJF."""
    mappings = []
    used_armature_bones = set()
    
    print(f"\n=== СОЗДАНИЕ МАППИНГА ===")
    print(f"Костей в CJF: {len(cjf_bones)}")
    print(f"Костей в арматуре: {len(armature_bones)}")
    
    # Создаём нормализованные версии имён для поиска
    normalized_armature = {}
    for bone in armature_bones:
        normalized = normalize_bone_name_for_matching(bone)
        if normalized not in normalized_armature:
            normalized_armature[normalized] = bone
    
    # Проходим по всем костям из CJF
    for cjf_idx, cjf_name in enumerate(cjf_bones):
        cjf_normalized = normalize_bone_name_for_matching(cjf_name)
        
        # Ищем точное совпадение
        matched_bone = None
        
        if cjf_normalized in normalized_armature:
            matched_bone = normalized_armature[cjf_normalized]
        
        # Если не нашли точное, ищем частичное
        if not matched_bone:
            for arm_bone in armature_bones:
                if arm_bone in used_armature_bones:
                    continue
                
                arm_normalized = normalize_bone_name_for_matching(arm_bone)
                
                # Проверяем различные варианты совпадения
                if (cjf_normalized == arm_normalized or
                    cjf_normalized in arm_normalized or
                    arm_normalized in cjf_normalized):
                    matched_bone = arm_bone
                    break
        
        # Если нашли совпадение
        if matched_bone and matched_bone not in used_armature_bones:
            mappings.append((cjf_idx, matched_bone))
            used_armature_bones.add(matched_bone)
            print(f"✓ CJF[{cjf_idx:3d}] '{cjf_name}' -> '{matched_bone}'")
        else:
            print(f"✗ CJF[{cjf_idx:3d}] '{cjf_name}' -> не найдено")
    
    # Для оставшихся костей арматуры
    remaining = [b for b in armature_bones if b not in used_armature_bones]
    if remaining:
        print(f"\nОсталось несопоставленных костей: {len(remaining)}")
        # Можно добавить дополнительную логику для их сопоставления
    
    return mappings


def normalize_bone_name_for_matching(name):
    """Нормализует имя кости для сопоставления."""
    if not name:
        return ""
    
    name = name.lower()
    
    # Убираем общие префиксы и суффиксы
    replacements = [
        ('as_', ''),
        ('_as', ''),
        ('bone', ''),
        ('_bone', ''),
        ('bone_', ''),
        ('left', 'l'),
        ('right', 'r'),
        ('_', ''),
        ('-', ''),
        (' ', '')
    ]
    
    for old, new in replacements:
        name = name.replace(old, new)
    
    return name

# ... существующие импорты ...

def fill_rotation_gaps(armature, action):
    """
    Проходит по всем костям в экшене. Если расстояние между ключами > 1 кадра,
    вставляет промежуточный ключ (50%) с использованием сферической интерполяции (Slerp).
    Также исправляет разрывы непрерывности кватернионов.
    """
    if not action:
        return

    # Группируем кривые по названиям костей
    bone_curves = {}
    for fcurve in action.fcurves:
        if "rotation_quaternion" in fcurve.data_path:
            # data_path выглядит как 'pose.bones["BoneName"].rotation_quaternion'
            bone_name = fcurve.data_path.split('"')[1]
            if bone_name not in bone_curves:
                bone_curves[bone_name] = []
            bone_curves[bone_name].append(fcurve)

    print(f"Checking gaps for {len(bone_curves)} bones...")
    
    bones_fixed = 0
    
    # Проходим по каждой кости
    for bone_name, curves in bone_curves.items():
        # Нам нужны все 4 компонента (W, X, Y, Z) чтобы собрать кватернион
        if len(curves) < 4:
            continue
            
        pose_bone = armature.pose.bones.get(bone_name)
        if not pose_bone:
            continue

        # Собираем все временные метки (кадры), где есть ключи
        keyframes = set()
        for fc in curves:
            for kp in fc.keyframe_points:
                keyframes.add(int(kp.co.x))
        
        sorted_frames = sorted(list(keyframes))
        if not sorted_frames:
            continue

        # Проходим по кадрам и ищем разрывы
        new_keys = [] # (frame, quaternion)
        
        # Для корректной интерполяции нам нужно знать значения в существующих кадрах
        # Blender API не дает простого доступа "дай значение кривой в кадре X", 
        # поэтому мы оцениваем кривую (evaluate)
        
        for i in range(len(sorted_frames) - 1):
            current_frame = sorted_frames[i]
            next_frame = sorted_frames[i+1]
            
            # Если разрыв больше 1 кадра (значит есть пропущенные кадры)
            if next_frame - current_frame > 1:
                mid_frame = (current_frame + next_frame) / 2
                
                # Получаем значения кватернионов в начале и конце разрыва
                # evaluate возвращает значение в этот момент времени
                w1 = curves[0].evaluate(current_frame)
                x1 = curves[1].evaluate(current_frame)
                y1 = curves[2].evaluate(current_frame)
                z1 = curves[3].evaluate(current_frame)
                
                w2 = curves[0].evaluate(next_frame)
                x2 = curves[1].evaluate(next_frame)
                y2 = curves[2].evaluate(next_frame)
                z2 = curves[3].evaluate(next_frame)
                
                q1 = Quaternion((w1, x1, y1, z1)).normalized()
                q2 = Quaternion((w2, x2, y2, z2)).normalized()
                
                # ВАЖНО: Проверка на кратчайший путь (fix antipodal)
                # Если q1 и q2 смотрят в разные стороны 4D сферы, инвертируем один
                if q1.dot(q2) < 0:
                    q2 = -q2
                
                # SLERP 50% (Сферическая линейная интерполяция)
                # Это дает математически идеальную середину вращения
                q_mid = q1.slerp(q2, 0.5)
                
                new_keys.append((mid_frame, q_mid))

        # Вставляем вычисленные промежуточные ключи
        if new_keys:
            bones_fixed += 1
            for frame, quat in new_keys:
                pose_bone.rotation_quaternion = quat
                pose_bone.keyframe_insert(data_path="rotation_quaternion", frame=frame)
                
            # Принудительно ставим LINEAR для новых ключей, чтобы не было "перехлестов"
            for fc in curves:
                for kp in fc.keyframe_points:
                    kp.interpolation = 'LINEAR'

    print(f"✓ Fixed gaps in {bones_fixed} bones.")
    # Обновляем сцену
    bpy.context.view_layer.update()