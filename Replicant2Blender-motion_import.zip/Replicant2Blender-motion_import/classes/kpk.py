from ..util import *
from .cmf import CMF

class KPK:
    def __init__(self, packFile):
        basePos = packFile.tell()

        self.magic = packFile.read(4)
        self.fileCount = to_uint(packFile.read(4))
        null = packFile.read(4)

        self.fileOffsets = []
        for i in range(self.fileCount):
            self.fileOffsets.append(to_uint(packFile.read(4)))

        self.fileSizes = []
        for i in range(self.fileCount):
            self.fileSizes.append(to_uint(packFile.read(4)))

        self.files = []
        for i in range(self.fileCount):
            if self.fileOffsets[i] == 0 or self.fileSizes[i] == 0:
                self.files.append(None)
                continue
            packFile.seek(basePos + self.fileOffsets[i])
            magic = packFile.read(4)
            packFile.seek(-4, 1)

            if magic in [b"CMF\x01", b"CMF\x03", b"CMF\x02"]:
                self.files.append(CMF(packFile))
            elif magic in [b"KPK\x7F", b"KPK\x79"]:  # Рекурсия для вложенных KPK
                self.files.append(KPK(packFile))
            else:
                print("Unknown file type:", magic)
                self.files.append(None)