# mdvl_importer.py
import bpy
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from classes.util import *
from classes.pack import Pack

def import_mdvl_file(filepath):
    with open(filepath, 'rb') as f:
        pack = Pack(f)
    
    cmfFiles = pack.cmfFiles  # Теперь рекурсивно собраны
    
    print(f"Found {len(cmfFiles)} animations in MDVL file")
    return pack, cmfFiles

# Остальное без изменений

# Интеграция с motionAssets_import.py
def import_motions_from_mdvl(filepath):
    """Основная функция для импорта анимаций из MDVL"""
    pack, cmfFiles = import_mdvl_file(filepath)
    
    # Проверить активный арматуру
    armature = bpy.context.active_object
    if not armature or armature.type != 'ARMATURE':
        raise Exception("Active object is not an armature")
    
    # Создать действия для каждого CMF
    parsed_cmfs = {}
    for cmf in cmfFiles:
        if not cmf or not hasattr(cmf, 'name'):
            continue
            
        print(f"Importing animation: {cmf.name}")
        
        # Удалить существующее действие
        if cmf.name in bpy.data.actions:
            bpy.data.actions.remove(bpy.data.actions[cmf.name])
        
        # Создать новое действие
        action = bpy.data.actions.new(cmf.name)
        action.use_fake_user = True
        
        # Сохранить для применения позже
        parsed_cmfs[cmf.name] = cmf
        
        print(f"✓ Animation prepared: {cmf.name}")
    
    return parsed_cmfs