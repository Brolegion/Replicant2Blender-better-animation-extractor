from ..util import *
from .bxon import *
from .kpk import *
from .cmf import CMF

class File:
    def __init__(self, packFile):
        self.magic = packFile.read(4)

        self.offsetToName = to_int(packFile.read(4))
        offsetName = packFile.tell() + self.offsetToName - 4

        self.fileSize = to_int(packFile.read(4))
        self.offsetToFileStart = to_int(packFile.read(4))
        offsetFileStart = packFile.tell() + self.offsetToFileStart - 4

        self.unknown0 = to_int(packFile.read(4))

        returnPos = packFile.tell()
        packFile.seek(offsetName)
        self.name = to_string(packFile.read(1024))
        
        print("\t[+]", self.name)

        packFile.seek(offsetFileStart)
        fileID = packFile.read(4)
        packFile.seek(-4, 1)
        if fileID == b"BXON":
            self.content = BXON(packFile)
        elif fileID in [b"KPK\x7F", b"KPK\x79"]:  # Поддержка обеих магий
            self.content = KPK(packFile)
        elif fileID in [b"CMF\x01", b"CMF\x02", b"CMF\x03"]:
            self.content = CMF(packFile)
        else:
            self.content = None
        
        packFile.seek(returnPos)