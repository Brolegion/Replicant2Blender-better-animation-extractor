import json
import bpy
from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, BoolProperty
from bpy.types import Operator

def export_cmf_to_json(filepath, cmf_data, export_all_animations=True, animation_names=None):
    """
    Экспортирует сырые данные CMF в JSON формат
    """
    export_data = {
        "export_info": {
            "format_version": "1.0", 
            "exported_animations": 0,
            "description": "Raw CMF animation data export"
        },
        "animations": {}
    }
    
    if export_all_animations:
        # Экспорт всех анимаций
        animations_to_export = cmf_data.keys()
    else:
        # Экспорт только выбранных анимаций
        animations_to_export = animation_names if animation_names else []
    
    exported_count = 0
    
    for anim_name in animations_to_export:
        if anim_name not in cmf_data:
            print(f"Animation {anim_name} not found in CMF data")
            continue
            
        cmf = cmf_data[anim_name]
        animation_data = {
            "name": cmf.name,
            "bone_count": cmf.boneCount,
            "frame_range": [0, cmf.framesCount - 1] if hasattr(cmf, 'framesCount') else [0, 0],
            "bones": {}
        }
        
        # Обрабатываем данные для каждой кости
        for bone_index in range(cmf.boneCount):
            bone_data = {
                "index": bone_index,
                "rotation": {"frames": [], "values": []},
                "location": {"frames": [], "values": []}
            }
            
            # Данные вращения (TransData1)
            trans_data1 = None
            if (hasattr(cmf, 'framesTransData1') and cmf.framesTransData1 and 
                bone_index < len(cmf.framesTransData1.transformations)):
                trans_data1 = cmf.framesTransData1.transformations[bone_index]
            
            if trans_data1 and hasattr(trans_data1, 'indices') and hasattr(trans_data1, 'values'):
                bone_data["rotation"]["frames"] = trans_data1.indices
                # Конвертируем значения в правильный формат [x, y, z, w]
                bone_data["rotation"]["values"] = [
                    [value[0], value[1], value[2], value[3]] 
                    for value in trans_data1.values
                ]
            
            # Данные позиции (TransData2)  
            trans_data2 = None
            if (hasattr(cmf, 'framesTransData2') and cmf.framesTransData2 and 
                bone_index < len(cmf.framesTransData2.transformations)):
                trans_data2 = cmf.framesTransData2.transformations[bone_index]
            
            if trans_data2 and hasattr(trans_data2, 'indices') and hasattr(trans_data2, 'values'):
                bone_data["location"]["frames"] = trans_data2.indices
                bone_data["location"]["values"] = trans_data2.values
            
            animation_data["bones"][str(bone_index)] = bone_data
        
        export_data["animations"][anim_name] = animation_data
        exported_count += 1
    
    export_data["export_info"]["exported_animations"] = exported_count
    
    # Сохраняем в файл
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(export_data, f, indent=2, ensure_ascii=False)
    
    return exported_count

class EXPORT_OT_CmfJson(Operator, ExportHelper):
    """Export raw CMF animation data to JSON"""
    bl_idname = "export_anim.cmf_json"
    bl_label = "Export CMF JSON"
    bl_description = "Export raw CMF animation data to JSON format"
    
    filename_ext = ".json"
    
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'}
    )
    
    export_all_animations: BoolProperty(
        name="Export All Animations",
        description="Export all loaded animations or only selected ones",
        default=True
    )
    
    def execute(self, context):
        from . import global_parsed_cmfs
        
        if not global_parsed_cmfs:
            self.report({'ERROR'}, "No CMF data loaded. Import motion pack first.")
            return {'CANCELLED'}
        
        try:
            # Определяем какие анимации экспортировать
            animation_names = None
            if not self.export_all_animations:
                # Экспорт только выбранной анимации
                armature = context.active_object
                if armature and armature.type == 'ARMATURE':
                    selected_motion = getattr(armature.data, 'selected_motion', None)
                    if selected_motion:
                        animation_names = [selected_motion]
            
            exported_count = export_cmf_to_json(
                self.filepath, 
                global_parsed_cmfs,
                self.export_all_animations,
                animation_names
            )
            
            self.report({'INFO'}, f"Successfully exported {exported_count} animations to JSON")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}

class MOTION_OT_ExportCurrentAnimation(Operator, ExportHelper):
    """Export currently selected animation to JSON"""
    bl_idname = "replicant.export_current_animation"
    bl_label = "Export Current Animation"
    bl_description = "Export currently selected animation to JSON format"
    
    filename_ext = ".json"
    
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'}
    )
    
    def execute(self, context):
        from . import global_parsed_cmfs
        
        if not global_parsed_cmfs:
            self.report({'ERROR'}, "No CMF data loaded. Import motion pack first.")
            return {'CANCELLED'}
        
        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "No active armature selected")
            return {'CANCELLED'}
            
        selected_motion = getattr(armature.data, 'selected_motion', None)
        if not selected_motion:
            self.report({'ERROR'}, "No motion selected in armature")
            return {'CANCELLED'}
            
        if selected_motion not in global_parsed_cmfs:
            self.report({'ERROR'}, f"Animation '{selected_motion}' not found in loaded data")
            return {'CANCELLED'}
        
        try:
            # Экспортируем только выбранную анимацию
            export_cmf_to_json(
                self.filepath, 
                global_parsed_cmfs,
                export_all_animations=False,
                animation_names=[selected_motion]
            )
            
            self.report({'INFO'}, f"Successfully exported '{selected_motion}' to JSON")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}

def menu_export_cmf_json(self, context):
    self.layout.operator(EXPORT_OT_CmfJson.bl_idname, text="NieR Replicant CMF JSON (.json)")