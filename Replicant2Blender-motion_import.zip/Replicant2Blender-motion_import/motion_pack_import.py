# motion_pack_import.py
import sys
import os

package_path = os.path.dirname(__file__)
if package_path not in sys.path:
    sys.path.insert(0, package_path)

import bpy
from .classes.pack import *
from .classes.cmf import CMF
from .importers.motionAssets_import import import_motions, get_cmfFiles, add_cmf_action

def main(packFilePath, addonName, parsed_cmfs):  # Добавлен параметр parsed_cmfs
    print(f"Parsing Motion file: {packFilePath}")

    with open(packFilePath, "rb") as packFile:
        # Читаем магию
        magic = packFile.read(4)
        packFile.seek(0)

        if magic == b"PACK":
            motionPack = Pack(packFile)
            print("Preparing CMF Motions...")
            import_motions(motionPack, parsed_cmfs)  # Используем переданный parsed_cmfs
        elif magic in [b"CMF\x01", b"CMF\x02", b"CMF\x03"]:
            cmf = CMF(packFile)
            add_cmf_action(cmf, parsed_cmfs)  # Используем переданный parsed_cmfs
        else:
            print(f"Unknown file type: {magic}")
            return

    print(f"Total parsed CMF files in global storage: {len(parsed_cmfs)}")