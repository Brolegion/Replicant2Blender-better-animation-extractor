# __init__.py
bl_info = {
    "name": "Replicant2Blender (NieR Replicant ver.1.2247... Mesh Pack Importer)",
    "author": "Woeful_Wolf",
    "version": (0, 7, 3),
    "blender": (4, 2, 0),
    "api": 38019,
    "location": "File > Import | 3D View > Side Panel",
    "description": "Import NieR Replicant Mesh Pack with enhanced animation mapping",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}

import sys
import os
import json
import math

# Фикс для relative imports в Blender
package_path = os.path.dirname(__file__)
if package_path not in sys.path:
    sys.path.insert(0, package_path)

import bpy
from mathutils import Matrix, Quaternion, Vector
from bpy_extras.io_utils import ExportHelper, ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty, CollectionProperty, IntProperty, PointerProperty, FloatProperty, FloatVectorProperty
from bpy.types import Operator, OperatorFileListElement, PropertyGroup, UIList, Panel


# Импорты после фикса sys.path
from . import mesh_pack_import
from . import motion_pack_import
from . import cmf_export  # Добавляем импорт экспортёра
# В начале __init__.py, где другие импорты:
from .importers.motionAssets_import import apply_mapped_animation, import_motions, transfer_n_all_to_armature, extract_bone_names_from_mdvl
from .importers import cmf_import

# Глобальное хранилище для всех CMF файлов из всех загруженных пакетов
global_parsed_cmfs = {}

# PropertyGroup для bone mappings
class BoneMapping(PropertyGroup):
    cmf_index: IntProperty(name="CMF Index", description="Index from CMF animation")
    bone_name: StringProperty(name="Bone Name", description="Armature bone name")

# UIList для отображения mappings
class REPLICANT_UL_BoneMapping(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row()
            row.prop(item, "cmf_index", text="")
            row.prop_search(item, "bone_name", context.active_object.data, "bones", text="")
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='BONE_DATA')

# В разделе с операторами (после MOTION_OT_ResetMapping) добавляем:

class MOTION_OT_ImportMDVLBones(Operator, ImportHelper):
    '''Import bone names from MDVL file (files without extension)'''
    bl_idname = "replicant.import_mdvl_bones"
    bl_label = "Import MDVL Bone Names"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Показывать все файлы
    filter_glob: StringProperty(
        default="*",
        options={'HIDDEN'}
    )
    
    def execute(self, context):
        armature = context.active_object
        
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature first")
            return {'CANCELLED'}
        
        try:
            # Извлекаем имена костей из файла MDVL
            from .importers.motionAssets_import import extract_bone_names_from_mdvl
            
            bone_names = extract_bone_names_from_mdvl(self.filepath)
            
            if not bone_names:
                self.report({'WARNING'}, "No bone names found in file")
                return {'CANCELLED'}
            
            # Автоматически создаем маппинг с улучшенным алгоритмом
            armature_bones = [b.name for b in armature.data.bones]
            
            # Очищаем существующий маппинг
            armature.data.motion_mappings.clear()
            
            # Улучшенный алгоритм маппинга
            mappings_created = self.create_improved_mapping(armature, bone_names, armature_bones)
            
            # Сортируем маппинг
            sort_mappings(armature)
            
            # Показываем результат
            print(f"\n=== РЕЗУЛЬТАТ МАППИНГА ===")
            print(f"Найдено в MDVL: {len(bone_names)} имен")
            print(f"Костей в арматуре: {len(armature_bones)}")
            print(f"Создано маппингов: {len(armature.data.motion_mappings)}")
            
            if armature.data.motion_mappings:
                print("\nСозданные маппинги:")
                for mapping in armature.data.motion_mappings:
                    print(f"  CMF индекс {mapping.cmf_index:3d} -> кость '{mapping.bone_name}'")
            
            self.report({'INFO'}, f"Imported {len(bone_names)} bone names, created {len(armature.data.motion_mappings)} mappings")
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import: {str(e)}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}
        
        return {'FINISHED'}
    
    def create_improved_mapping(self, armature, mdvl_bones, armature_bones):
        """Создает улучшенный маппинг с учетом похожести имен."""
        mappings_created = 0
        
        # Сначала пробуем точные совпадения (игнорируя регистр)
        mdvl_lower = {name.lower(): idx for idx, name in enumerate(mdvl_bones)}
        
        for i, arm_bone in enumerate(armature_bones):
            arm_lower = arm_bone.lower()
            
            # Прямое совпадение
            if arm_lower in mdvl_lower:
                cmf_index = mdvl_lower[arm_lower]
                mapping = armature.data.motion_mappings.add()
                mapping.cmf_index = cmf_index
                mapping.bone_name = arm_bone
                mappings_created += 1
                print(f"Точное совпадение: '{arm_bone}' -> индекс {cmf_index}")
        
        # Если точных совпадений мало, пробуем частичные
        if mappings_created < len(armature_bones) / 2:
            for i, arm_bone in enumerate(armature_bones):
                # Пропускаем уже сопоставленные кости
                if any(m.bone_name == arm_bone for m in armature.data.motion_mappings):
                    continue
                
                arm_lower = arm_bone.lower()
                best_match_idx = -1
                best_match_score = 0
                
                # Ищем наиболее похожее имя в MDVL
                for j, mdvl_bone in enumerate(mdvl_bones):
                    # Пропускаем уже использованные индексы
                    if any(m.cmf_index == j for m in armature.data.motion_mappings):
                        continue
                    
                    mdvl_lower = mdvl_bone.lower()
                    
                    # Вычисляем схожесть
                    similarity = self.calculate_similarity(arm_lower, mdvl_lower)
                    
                    if similarity > best_match_score and similarity > 0.5:
                        best_match_score = similarity
                        best_match_idx = j
                
                if best_match_idx != -1:
                    mapping = armature.data.motion_mappings.add()
                    mapping.cmf_index = best_match_idx
                    mapping.bone_name = arm_bone
                    mappings_created += 1
                    print(f"Частичное совпадение: '{arm_bone}' -> '{mdvl_bones[best_match_idx]}' (индекс {best_match_idx}, схожесть: {best_match_score:.2f})")
        
        # Оставшиеся кости сопоставляем по порядку
        used_indices = set(m.cmf_index for m in armature.data.motion_mappings)
        unused_indices = [i for i in range(len(mdvl_bones)) if i not in used_indices]
        unmapped_bones = [b for b in armature_bones if b not in [m.bone_name for m in armature.data.motion_mappings]]
        
        for i, (cmf_idx, arm_bone) in enumerate(zip(unused_indices, unmapped_bones)):
            mapping = armature.data.motion_mappings.add()
            mapping.cmf_index = cmf_idx
            mapping.bone_name = arm_bone
            mappings_created += 1
            print(f"Автоматическое сопоставление: '{arm_bone}' -> индекс {cmf_idx}")
        
        return mappings_created
    
    def calculate_similarity(self, str1, str2):
        """Вычисляет схожесть двух строк (0.0 - 1.0)."""
        # Удаляем общие префиксы/суффиксы
        str1_clean = str1.replace('_', '').replace(' ', '')
        str2_clean = str2.replace('_', '').replace(' ', '')
        
        # Если строки идентительны после очистки
        if str1_clean == str2_clean:
            return 1.0
        
        # Если одна строка содержит другую
        if str1_clean in str2_clean or str2_clean in str1_clean:
            return 0.8
        
        # Вычисляем пересечение символов
        set1 = set(str1_clean)
        set2 = set(str2_clean)
        intersection = len(set1 & set2)
        union = len(set1 | set2)
        
        if union == 0:
            return 0.0
        
        return intersection / union

# Panel for motion mapping
class MOTION_PT_MappingPanel(Panel):
    bl_label = "Motion Mapping"
    bl_idname = "MOTION_PT_mapping_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Replicant"

    def draw(self, context):
        layout = self.layout
        armature = context.active_object
        
        if not armature or armature.type != 'ARMATURE':
            layout.label(text="Select an armature")
            return
        
        # Основной выбор анимации
        row = layout.row()
        row.prop_search(armature.data, "selected_motion", bpy.data, "actions", text="Select Motion")
        
        # N_ALL transfer option
        box = layout.box()
        box.prop(armature.data, "transfer_n_all_to_armature", text="Transfer N_ALL to Armature")
        if armature.data.transfer_n_all_to_armature:
            box.operator("replicant.transfer_n_all_to_armature", text="Apply N_ALL Transfer")
        
        # Простая кнопка для импорта MDVL
        box = layout.box()
        box.label(text="MDVL Bone Import:", icon='IMPORT')
        box.operator("replicant.import_mdvl_bones", 
                    text="Import Bone Names from File")
        
        # Показываем статистику текущего маппинга
        if armature.data.motion_mappings:
            box.label(text=f"Mapped: {len(armature.data.motion_mappings)} bones", icon='CHECKMARK')
        
        # Остальная часть панели без изменений
        if armature.data.selected_motion:
            layout.label(text="Bone Mappings:")
            row = layout.row()
            row.template_list("REPLICANT_UL_BoneMapping", "", 
                            armature.data, "motion_mappings", 
                            armature.data, "active_mapping_index", rows=5)
            
            col = row.column(align=True)
            col.operator("replicant.add_mapping", icon='ADD', text="")
            col.operator("replicant.remove_mapping", icon='REMOVE', text="")
            col.operator("replicant.shift_mapping_increase", icon='ADD', text="")
            col.operator("replicant.shift_mapping_decrease", icon='REMOVE', text="")
            
            layout.operator("replicant.apply_motion_mapping", text="Apply Mapping")
            layout.operator("replicant.reset_mapping", text="Reset to Auto")
            
            layout.separator()
            layout.label(text="Transformation Mode:")
            layout.prop(armature.data, "transformation_mode", text="")
            
            layout.separator()
            layout.operator("replicant.export_current_animation", 
                          text="Export Current Animation to JSON", icon='FILE_SCRIPT')
            layout.separator()
            box = layout.box()
            box.label(text="Fixes & Tools:", icon='MODIFIER')
            # Новая кнопка
            box.operator("replicant.fill_gaps", text="Fill Rotation Gaps (Fix Jitter)", icon='GRAPH')
            
            layout.separator()
            row = layout.row()
            row.operator("replicant.save_mappings", text="Save Mappings", icon='EXPORT')
            row.operator("replicant.load_mappings", text="Load Mappings", icon='IMPORT')

def sort_mappings(armature):
    temp = [(m.cmf_index, m.bone_name) for m in armature.data.motion_mappings]
    temp.sort(key=lambda x: x[0])
    armature.data.motion_mappings.clear()
    for idx, name in temp:
        m = armature.data.motion_mappings.add()
        m.cmf_index = idx
        m.bone_name = name

# Operator to add mapping
class MOTION_OT_AddMapping(Operator):
    bl_idname = "replicant.add_mapping"
    bl_label = "Add Mapping"

    def execute(self, context):
        armature = context.active_object
        if armature and armature.type == 'ARMATURE':
            mapping = armature.data.motion_mappings.add()
            mapping.cmf_index = len(armature.data.motion_mappings) - 1
            sort_mappings(armature)
        return {'FINISHED'}

# Operator to remove mapping
class MOTION_OT_RemoveMapping(Operator):
    bl_idname = "replicant.remove_mapping"
    bl_label = "Remove Mapping"

    def execute(self, context):
        armature = context.active_object
        if armature and armature.type == 'ARMATURE':
            index = armature.data.active_mapping_index
            if 0 <= index < len(armature.data.motion_mappings):
                armature.data.motion_mappings.remove(index)
                sort_mappings(armature)
        return {'FINISHED'}

# Operator to shift mappings increase
class MOTION_OT_ShiftMappingIncrease(Operator):
    bl_idname = "replicant.shift_mapping_increase"
    bl_label = "Increase Indices from Selected"

    def execute(self, context):
        armature = context.active_object
        if armature and armature.type == 'ARMATURE':
            index = armature.data.active_mapping_index
            if 0 <= index < len(armature.data.motion_mappings):
                active_cmf = armature.data.motion_mappings[index].cmf_index
                for m in armature.data.motion_mappings:
                    if m.cmf_index >= active_cmf:
                        m.cmf_index += 1
                sort_mappings(armature)
        return {'FINISHED'}

# Operator to shift mappings decrease
class MOTION_OT_ShiftMappingDecrease(Operator):
    bl_idname = "replicant.shift_mapping_decrease"
    bl_label = "Decrease Indices from Selected"

    def execute(self, context):
        armature = context.active_object
        if armature and armature.type == 'ARMATURE':
            index = armature.data.active_mapping_index
            if 0 <= index < len(armature.data.motion_mappings):
                active_cmf = armature.data.motion_mappings[index].cmf_index
                for m in armature.data.motion_mappings:
                    if m.cmf_index >= active_cmf and m.cmf_index > 0:
                        m.cmf_index -= 1
                sort_mappings(armature)
        return {'FINISHED'}

# Operator to reset mapping to auto
class MOTION_OT_ResetMapping(Operator):
    bl_idname = "replicant.reset_mapping"
    bl_label = "Reset Mapping"

    def execute(self, context):
        armature = context.active_object
        if armature and armature.type == 'ARMATURE':
            has_n_all = any(b.name == "N_ALL" for b in armature.data.bones)
            offset = 0 if has_n_all else 1
            armature.data.motion_mappings.clear()
            # Auto populate based on default (index to bone[index])
            for i, bone in enumerate(armature.data.bones):
                mapping = armature.data.motion_mappings.add()
                mapping.cmf_index = i + offset
                mapping.bone_name = bone.name
            sort_mappings(armature)
        return {'FINISHED'}

# Operator to apply mapping to selected action
class MOTION_OT_ApplyMapping(Operator):
    bl_idname = "replicant.apply_motion_mapping"
    bl_label = "Apply Motion Mapping"
    bl_description = "Apply the current bone mappings to the selected motion action"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "No active armature selected")
            return {'CANCELLED'}
            
        action_name = armature.data.selected_motion
        if not action_name:
            self.report({'ERROR'}, "No motion selected")
            return {'CANCELLED'}
            
        if action_name not in bpy.data.actions:
            self.report({'ERROR'}, f"Action '{action_name}' not found")
            return {'CANCELLED'}

        # Force pose mode and deselect all bones
        bpy.ops.object.mode_set(mode='POSE')
        bpy.ops.pose.select_all(action='DESELECT')
        
        # Reset all bones to rest position
        for bone in armature.pose.bones:
            bone.matrix_basis = Matrix.Identity(4)

        try:
            # Используем выбранный режим трансформации
            transformation_mode = armature.data.transformation_mode
            
            # Используем глобальное хранилище
            apply_mapped_animation(armature, action_name, global_parsed_cmfs, transformation_mode=transformation_mode)
            
            # Если включена опция передачи N_ALL на арматуру
            if armature.data.transfer_n_all_to_armature:
                transfer_n_all_to_armature(armature, action_name, global_parsed_cmfs)
                
            self.report({'INFO'}, f"Successfully applied '{action_name}' with mode: {transformation_mode}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply animation: {str(e)}")
            return {'CANCELLED'}
            
        return {'FINISHED'}

# Operator for N_ALL transfer
class MOTION_OT_TransferNALLToArmature(Operator):
    bl_idname = "replicant.transfer_n_all_to_armature"
    bl_label = "Transfer N_ALL to Armature"
    bl_description = "Transfer root bone (N_ALL) animation to armature object"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "No active armature selected")
            return {'CANCELLED'}
            
        action_name = armature.data.selected_motion
        if not action_name:
            self.report({'ERROR'}, "No motion selected")
            return {'CANCELLED'}
            
        try:
            transfer_n_all_to_armature(armature, action_name, global_parsed_cmfs)
            self.report({'INFO'}, f"Transferred N_ALL animation to armature for '{action_name}'")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to transfer N_ALL animation: {str(e)}")
            return {'CANCELLED'}
            
        return {'FINISHED'}

class ImportReplicantMeshPack(bpy.types.Operator, ImportHelper):
    '''Import NieR Replicant Mesh Pack File(s)'''
    bl_idname = "import_scene.replicant_mesh_pack"
    bl_label = "Import File(s)"
    bl_options = {'PRESET', "REGISTER", "UNDO"}
    files: CollectionProperty(
            name="File Path",
            type=OperatorFileListElement)
    directory: StringProperty(subtype='DIR_PATH')
    batch_size: IntProperty(name="Texture Conversion Batch Size", default=15, description="Batch sizes when converting textures. Higher values will be faster but require more CPU resources", min=1)
    extract_textures: BoolProperty(name="Extract Textures (Slow)", description="This automatically extracts and converts textures to PNG (Requires the user to have setup Noesis in this add-on's preferences)", default=True)
    construct_materials: BoolProperty(name="Construct Materials", description="This automatically sets up materials with the appropriate textures (Requires the user to have extracted the textures at least once before)", default=True)
    only_extract_textures: BoolProperty(name="Only Extract Textures", description="This can be used to simply extract the textures from a PACK containing some, nothing else will be done (Requires the user to have setup Noesis in this add-on's preferences)", default=False)

    def execute(self, context):
        directory = self.directory
        for file_elem in self.files:
            filepath = os.path.join(directory, file_elem.name)
            if os.path.isfile(filepath):
                if self.only_extract_textures:
                    mesh_pack_import.only_extract_textures(filepath, self.batch_size, __name__)
                else:
                    mesh_pack_import.main(filepath, self.extract_textures, self.construct_materials, self.batch_size, __name__)
        mesh_pack_import.clear_importLists()
        return {"FINISHED"}

class ImportReplicantMotionPack(bpy.types.Operator, ImportHelper):
    '''Import NieR Replicant Motion Pack File(s)'''
    bl_idname = "import_scene.replicant_motion_pack"
    bl_label = "Import File(s)"
    bl_options = {'PRESET', "REGISTER", "UNDO"}
    files: CollectionProperty(
            name="File Path",
            type=OperatorFileListElement)
    directory: StringProperty(subtype='DIR_PATH')

    def execute(self, context):
        directory = self.directory
        for file_elem in self.files:
            filepath = os.path.join(directory, file_elem.name)
            if os.path.isfile(filepath):
                motion_pack_import.main(filepath, __name__, global_parsed_cmfs)  # Добавлен global_parsed_cmfs
        return {"FINISHED"}

class SelectNoesisExecutable(bpy.types.Operator, ImportHelper):
    '''Select Noesis Executable'''
    bl_idname = "replicant.noesis_select"
    bl_label = "Select Noesis Executable"
    filename_ext = ".exe"
    filter_glob: StringProperty(default="*.exe", options={'HIDDEN'})

    def execute(self, context):
        context.preferences.addons[__name__].preferences.noesis_path = self.filepath
        return {'FINISHED'}

class REPLICANT_PT_AxisSettings(Panel):
    bl_label = "Axis Settings"
    bl_idname = "REPLICANT_PT_axis_settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Replicant"
    bl_order = 1  # Чтобы панель была первой
    
    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__name__].preferences
        
        box = layout.box()
        box.label(text="Mesh Import Axis Remapping:", icon='MESH_DATA')
        row = box.row()
        row.prop(prefs, "mesh_axis_remap_x", text="X →")
        row.prop(prefs, "mesh_axis_remap_y", text="Y →")
        row.prop(prefs, "mesh_axis_remap_z", text="Z →")
        
        box = layout.box()
        box.label(text="Animation Import Axis Remapping:", icon='ANIM_DATA')
        row = box.row()
        row.prop(prefs, "anim_axis_remap_x", text="X →")
        row.prop(prefs, "anim_axis_remap_y", text="Y →")
        row.prop(prefs, "anim_axis_remap_z", text="Z →")
        
        # Предустановленные конфигурации
        box = layout.box()
        box.label(text="Preset Configurations:")
        
        row = box.row(align=True)
        row.operator("replicant.set_axis_preset", text="Z-up to Y-up").preset = 'Z_UP_TO_Y_UP'
        row.operator("replicant.set_axis_preset", text="Y-up to Z-up").preset = 'Y_UP_TO_Z_UP'
        
        row = box.row(align=True)
        row.operator("replicant.set_axis_preset", text="Swap Y-Z").preset = 'SWAP_YZ'
        row.operator("replicant.set_axis_preset", text="Swap X-Z").preset = 'SWAP_XZ'
        row.operator("replicant.set_axis_preset", text="Swap X-Y").preset = 'SWAP_XY'
        
        row = box.row(align=True)
        row.operator("replicant.set_axis_preset", text="Invert X").preset = 'INVERT_X'
        row.operator("replicant.set_axis_preset", text="Invert Y").preset = 'INVERT_Y'
        row.operator("replicant.set_axis_preset", text="Invert Z").preset = 'INVERT_Z'
        row.operator("replicant.set_axis_preset", text="None").preset = 'NONE'
        box = layout.box()
        box.label(text="Bone Import Settings:", icon='BONE_DATA')
        box.prop(prefs, "import_mode", text="Apply Axis Remapping to Bones")

class ImportReplicantCMFFile(bpy.types.Operator, ImportHelper):
    '''Import NieR Replicant CMF Animation File(s)'''
    bl_idname = "import_scene.replicant_cmf_file"
    bl_label = "Import CMF File(s)"
    bl_options = {'PRESET', "REGISTER", "UNDO"}
    files: CollectionProperty(
            name="File Path",
            type=OperatorFileListElement)
    directory: StringProperty(subtype='DIR_PATH')
    
    # Добавляем фильтр для CMF файлов
    filter_glob: StringProperty(
        default="*.cmf;*.bin;*.dat",
        options={'HIDDEN'}
    )

    def execute(self, context):
        directory = self.directory
        success_count = 0
        fail_count = 0
        
        for file_elem in self.files:
            filepath = os.path.join(directory, file_elem.name)
            if os.path.isfile(filepath):
                try:
                    if cmf_import.main(filepath, __name__, global_parsed_cmfs):
                        success_count += 1
                    else:
                        fail_count += 1
                except Exception as e:
                    self.report({'ERROR'}, f"Failed to import {file_elem.name}: {str(e)}")
                    fail_count += 1
        
        # Сообщаем о результате
        if success_count > 0:
            self.report({'INFO'}, f"Successfully imported {success_count} CMF files")
        if fail_count > 0:
            self.report({'WARNING'}, f"Failed to import {fail_count} files")
        
        return {"FINISHED"}


class REPLICANT_OT_SetAxisPreset(Operator):
    """Устанавливает предустановленную конфигурацию осей"""
    bl_idname = "replicant.set_axis_preset"
    bl_label = "Set Axis Preset"
    
    preset: EnumProperty(
        name="Preset",
        items=[
            ('Z_UP_TO_Y_UP', 'Z-up to Y-up', 'Convert from Z-up to Y-up'),
            ('Y_UP_TO_Z_UP', 'Y-up to Z-up', 'Convert from Y-up to Z-up'),
            ('SWAP_YZ', 'Swap Y-Z', 'Swap Y and Z axes'),
            ('SWAP_XZ', 'Swap X-Z', 'Swap X and Z axes'),
            ('SWAP_XY', 'Swap X-Y', 'Swap X and Y axes'),
            ('INVERT_X', 'Invert X', 'Invert X axis'),
            ('INVERT_Y', 'Invert Y', 'Invert Y axis'),
            ('INVERT_Z', 'Invert Z', 'Invert Z axis'),
            ('NONE', 'No Change', 'No transformation'),
        ]
    )
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        
        preset_configs = {
            'Z_UP_TO_Y_UP': {'x': '+X', 'y': '+Z', 'z': '-Y'},  # X→X, Y→Z, Z→-Y
            'Y_UP_TO_Z_UP': {'x': '+X', 'y': '-Z', 'z': '+Y'},  # X→X, Y→-Z, Z→Y
            'SWAP_YZ': {'x': '+X', 'y': '+Z', 'z': '+Y'},      # X→X, Y→Z, Z→Y
            'SWAP_XZ': {'x': '+Z', 'y': '+Y', 'z': '+X'},      # X→Z, Y→Y, Z→X
            'SWAP_XY': {'x': '+Y', 'y': '+X', 'z': '+Z'},      # X→Y, Y→X, Z→Z
            'INVERT_X': {'x': '-X', 'y': '+Y', 'z': '+Z'},     # X→-X, Y→Y, Z→Z
            'INVERT_Y': {'x': '+X', 'y': '-Y', 'z': '+Z'},     # X→X, Y→-Y, Z→Z
            'INVERT_Z': {'x': '+X', 'y': '+Y', 'z': '-Z'},     # X→X, Y→Y, Z→-Z
            'NONE': {'x': '+X', 'y': '+Y', 'z': '+Z'},         # No change
        }
        
        if self.preset in preset_configs:
            config = preset_configs[self.preset]
            prefs.mesh_axis_remap_x = config['x']
            prefs.mesh_axis_remap_y = config['y']
            prefs.mesh_axis_remap_z = config['z']
            
            # По умолчанию применяем те же настройки к анимации
            prefs.anim_axis_remap_x = config['x']
            prefs.anim_axis_remap_y = config['y']
            prefs.anim_axis_remap_z = config['z']
            
            self.report({'INFO'}, f"Applied preset: {self.preset}")
        
        return {'FINISHED'}

class Replicant2BlenderPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    noesis_path: StringProperty(options={'HIDDEN'})
    assets_path: StringProperty(options={'HIDDEN'})
    
    import_mode: BoolProperty(
        name="Use Axis Remapping for Bones",
        description="Apply axis remapping to bone matrices during import",
        default=False
    )
    def draw(self, context):
        layout = self.layout
        layout.label(text="Automatic texture & material setup requires that you have Noesis:")
        row = layout.row()
        row.operator("wm.url_open", text="Noesis Download").url = "https://richwhitehouse.com/index.php?content=inc_projects.php"
        layout.label(text="Path To Noesis Executable:")
        if os.name != 'nt':
            layout.label(text="If you aren't on Windows this probably won't work out of the box, but I'll leave it accessible anyways.")
        row = layout.row()
        row.prop(self, "noesis_path", text="")
        row.operator("replicant.noesis_select", icon="FILE_TICK", text="")
        layout.label(text="Path To Assets Folder:")
        row = layout.row()
        row.prop(self, "assets_path", text="")
    
    # Настройки для мешей - поддержка 48 вариантов
    mesh_axis_remap_x: EnumProperty(
        name="X Axis",
        description="Target axis for X",
        items=[
            ('+X', '+X', 'Positive X'),
            ('-X', '-X', 'Negative X'),
            ('+Y', '+Y', 'Positive Y'),
            ('-Y', '-Y', 'Negative Y'),
            ('+Z', '+Z', 'Positive Z'),
            ('-Z', '-Z', 'Negative Z'),
        ],
        default='+X'
    )
    
    mesh_axis_remap_y: EnumProperty(
        name="Y Axis",
        description="Target axis for Y",
        items=[
            ('+X', '+X', 'Positive X'),
            ('-X', '-X', 'Negative X'),
            ('+Y', '+Y', 'Positive Y'),
            ('-Y', '-Y', 'Negative Y'),
            ('+Z', '+Z', 'Positive Z'),
            ('-Z', '-Z', 'Negative Z'),
        ],
        default='+Y'
    )
    
    mesh_axis_remap_z: EnumProperty(
        name="Z Axis",
        description="Target axis for Z",
        items=[
            ('+X', '+X', 'Positive X'),
            ('-X', '-X', 'Negative X'),
            ('+Y', '+Y', 'Positive Y'),
            ('-Y', '-Y', 'Negative Y'),
            ('+Z', '+Z', 'Positive Z'),
            ('-Z', '-Z', 'Negative Z'),
        ],
        default='+Z'
    )
    
    # Настройки для анимации - поддержка 48 вариантов
    anim_axis_remap_x: EnumProperty(
        name="X Axis",
        description="Target axis for X in animations",
        items=[
            ('+X', '+X', 'Positive X'),
            ('-X', '-X', 'Negative X'),
            ('+Y', '+Y', 'Positive Y'),
            ('-Y', '-Y', 'Negative Y'),
            ('+Z', '+Z', 'Positive Z'),
            ('-Z', '-Z', 'Negative Z'),
        ],
        default='+X'
    )
    
    anim_axis_remap_y: EnumProperty(
        name="Y Axis",
        description="Target axis for Y in animations",
        items=[
            ('+X', '+X', 'Positive X'),
            ('-X', '-X', 'Negative X'),
            ('+Y', '+Y', 'Positive Y'),
            ('-Y', '-Y', 'Negative Y'),
            ('+Z', '+Z', 'Positive Z'),
            ('-Z', '-Z', 'Negative Z'),
        ],
        default='+Y'
    )
    
    anim_axis_remap_z: EnumProperty(
        name="Z Axis",
        description="Target axis for Z in animations",
        items=[
            ('+X', '+X', 'Positive X'),
            ('-X', '-X', 'Negative X'),
            ('+Y', '+Y', 'Positive Y'),
            ('-Y', '-Y', 'Negative Y'),
            ('+Z', '+Z', 'Positive Z'),
            ('-Z', '-Z', 'Negative Z'),
        ],
        default='+Z'
    )
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Automatic texture & material setup requires that you have Noesis:")
        row = layout.row()
        row.operator("wm.url_open", text="Noesis Download").url = "https://richwhitehouse.com/index.php?content=inc_projects.php"
        layout.label(text="Path To Noesis Executable:")
        if os.name != 'nt':
            layout.label(text="If you aren't on Windows this probably won't work out of the box, but I'll leave it accessible anyways.")
        row = layout.row()
        row.prop(self, "noesis_path", text="")
        row.operator("replicant.noesis_select", icon="FILE_TICK", text="")
        layout.label(text="Path To Assets Folder:")
        row = layout.row()
        row.prop(self, "assets_path", text="")
        # Добавляем раздел для 48-вариантных преобразований
        layout.separator()
        layout.label(text="48-Variant Axis Remapping:", icon='EMPTY_AXIS')
        
        box = layout.box()
        box.label(text="Mesh Import:")
        row = box.row()
        row.prop(self, "mesh_axis_remap_x", text="X →")
        row.prop(self, "mesh_axis_remap_y", text="Y →")
        row.prop(self, "mesh_axis_remap_z", text="Z →")
        
        box = layout.box()
        box.label(text="Animation Import:")
        row = box.row()
        row.prop(self, "anim_axis_remap_x", text="X →")
        row.prop(self, "anim_axis_remap_y", text="Y →")
        row.prop(self, "anim_axis_remap_z", text="Z →")
        
        # Предустановленные конфигурации
        box = layout.box()
        box.label(text="Preset Configurations:")
        
        row = box.row(align=True)
        row.operator("replicant.set_axis_preset", text="Z-up to Y-up").preset = 'Z_UP_TO_Y_UP'
        row.operator("replicant.set_axis_preset", text="Y-up to Z-up").preset = 'Y_UP_TO_Z_UP'
        
        row = box.row(align=True)
        row.operator("replicant.set_axis_preset", text="Swap Y-Z").preset = 'SWAP_YZ'
        row.operator("replicant.set_axis_preset", text="Swap X-Z").preset = 'SWAP_XZ'
        row.operator("replicant.set_axis_preset", text="Swap X-Y").preset = 'SWAP_XY'

class MOTION_OT_FillGaps(Operator):
    bl_idname = "replicant.fill_gaps"
    bl_label = "Fill Animation Gaps (50/50)"
    bl_description = "Inserts keyframes in gaps between existing keys using Slerp (50/50 mix). Fixes jitter/flipping."
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "Select an armature")
            return {'CANCELLED'}
            
        action = armature.animation_data.action if armature.animation_data else None
        if not action:
            self.report({'ERROR'}, "No action active on armature")
            return {'CANCELLED'}
            
        from .importers.motionAssets_import import fill_rotation_gaps
        
        try:
            fill_rotation_gaps(armature, action)
            self.report({'INFO'}, "Gaps filled successfully")
        except Exception as e:
            self.report({'ERROR'}, f"Error: {str(e)}")
            return {'CANCELLED'}
            
        return {'FINISHED'}


# Operator to save mappings to file
class MOTION_OT_SaveMappings(Operator, ExportHelper):
    bl_idname = "replicant.save_mappings"
    bl_label = "Save Bone Mappings"
    bl_description = "Save current bone mappings to text file"
    
    filename_ext = ".txt"
    filter_glob: StringProperty(default="*.txt", options={'HIDDEN'})
    
    def execute(self, context):
        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "No active armature selected")
            return {'CANCELLED'}
            
        try:
            with open(self.filepath, 'w') as f:
                for mapping in armature.data.motion_mappings:
                    f.write(f"{mapping.cmf_index}:{mapping.bone_name}\n")
            
            self.report({'INFO'}, f"Mappings saved to {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save mappings: {str(e)}")
            return {'CANCELLED'}
            
        return {'FINISHED'}

# Operator to load mappings from file
class MOTION_OT_LoadMappings(Operator, ImportHelper):
    bl_idname = "replicant.load_mappings"
    bl_label = "Load Bone Mappings"
    bl_description = "Load bone mappings from text file"
    
    filename_ext = ".txt"
    filter_glob: StringProperty(default="*.txt", options={'HIDDEN'})
    
    def execute(self, context):
        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "No active armature selected")
            return {'CANCELLED'}
            
        try:
            armature.data.motion_mappings.clear()
            
            with open(self.filepath, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    line = line.strip()
                    if line and ':' in line:
                        parts = line.split(':', 1)
                        if len(parts) == 2:
                            cmf_index = int(parts[0].strip())
                            bone_name = parts[1].strip()
                            
                            # Проверяем существует ли кость
                            if bone_name in armature.data.bones:
                                mapping = armature.data.motion_mappings.add()
                                mapping.cmf_index = cmf_index
                                mapping.bone_name = bone_name
                            else:
                                print(f"Warning: Bone '{bone_name}' not found in armature")
            
            sort_mappings(armature)
            self.report({'INFO'}, f"Mappings loaded from {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load mappings: {str(e)}")
            return {'CANCELLED'}
            
        return {'FINISHED'}


# Registration
def replicant_import_mesh_pack(self, context):
    self.layout.operator(ImportReplicantMeshPack.bl_idname, text="NieR Replicant Mesh Pack(s)")

def replicant_import_motion_pack(self, context):
    self.layout.operator(ImportReplicantMotionPack.bl_idname, text="NieR Replicant Motion Pack(s)")
    
def replicant_import_cmf_file(self, context):
    self.layout.operator(ImportReplicantCMFFile.bl_idname, text="NieR Replicant CMF File(s)")

# Registration
def register():
    # Register classes в правильном порядке
    bpy.utils.register_class(BoneMapping)
    bpy.utils.register_class(REPLICANT_UL_BoneMapping)
    
    # Панели
    bpy.utils.register_class(MOTION_PT_MappingPanel)
    
    # Операторы
    bpy.utils.register_class(MOTION_OT_AddMapping)
    bpy.utils.register_class(MOTION_OT_RemoveMapping)
    bpy.utils.register_class(MOTION_OT_ShiftMappingIncrease)
    bpy.utils.register_class(MOTION_OT_ShiftMappingDecrease)
    bpy.utils.register_class(MOTION_OT_ResetMapping)
    bpy.utils.register_class(MOTION_OT_ApplyMapping)
    bpy.utils.register_class(MOTION_OT_TransferNALLToArmature)
    bpy.utils.register_class(cmf_export.EXPORT_OT_CmfJson)
    bpy.utils.register_class(cmf_export.MOTION_OT_ExportCurrentAnimation)
    bpy.utils.register_class(MOTION_OT_SaveMappings)
    bpy.utils.register_class(MOTION_OT_LoadMappings)
    
    # Импортеры и настройки
    bpy.utils.register_class(ImportReplicantMeshPack)
    bpy.utils.register_class(ImportReplicantMotionPack)
    bpy.utils.register_class(SelectNoesisExecutable)
    bpy.utils.register_class(REPLICANT_OT_SetAxisPreset)
    bpy.utils.register_class(REPLICANT_PT_AxisSettings)
    bpy.utils.register_class(Replicant2BlenderPreferences)
    bpy.utils.register_class(ImportReplicantCMFFile)
    bpy.utils.register_class(MOTION_OT_ImportMDVLBones)
    
    bpy.utils.register_class(MOTION_OT_FillGaps)


    
    # Then assign properties to Armature
    bpy.types.Armature.motion_mappings = CollectionProperty(type=BoneMapping)
    bpy.types.Armature.selected_motion = StringProperty(name="Selected Motion", description="Selected action for mapping")
    bpy.types.Armature.active_mapping_index = IntProperty()
    
    # New property for N_ALL transfer
    bpy.types.Armature.transfer_n_all_to_armature = BoolProperty(
        name="Transfer N_ALL to Armature", 
        description="Transfer root bone (N_ALL) animation to armature object, even if n_all bone doesn't exist in skeleton",
        default=False
    )
    
    # New property for transformation mode with more options
    bpy.types.Armature.transformation_mode = EnumProperty(
        name="Transformation Mode",
        description="How animation data from CMF should be interpreted",
        items=[
            ('ABSOLUTE', 'Absolute', ''),
            ('RELATIVE', 'Relative', ''),
            ('ABSOLUTE_INVERTED', 'Absolute Inverted', ''),
            ('RELATIVE_INVERTED', 'Relative Inverted', ''),
            ('WORLD_SPACE', 'World Space', ''),
            ('DIRECT', 'Direct', ''),
            ('RELATIVE_ROT_ABS_POS', 'Relative Rot + Abs Pos', ''),
            ('ABS_ROT_REL_POS', 'Abs Rot + Relative Pos', ''),
            ('INVERTED_ANIM_ROT', 'Inverted Anim', ''),
            ('AXIS_SWAP_ROT', 'Axis Swap', ''),
            ('NORMALIZED_DELTA', 'Normalized Delta', ''),
            ('PARENT_ADJUSTED', 'Parent Adjusted', ''),
            ('DELTA_INVERTED', 'Delta Inverted', ''),
            ('GAME_AXIS_ADJUST', 'Game Axis Adjust', ''),
        ],
        default='ABSOLUTE'
    )

    bpy.types.TOPBAR_MT_file_import.append(replicant_import_mesh_pack)
    bpy.types.TOPBAR_MT_file_import.append(replicant_import_motion_pack)
    bpy.types.TOPBAR_MT_file_export.append(cmf_export.menu_export_cmf_json)
    bpy.types.TOPBAR_MT_file_import.append(replicant_import_cmf_file)
    bpy.types.Armature.disable_location_enabled = BoolProperty(
        name="Disable Location on Bones", 
        description="Disable location animation on bones with specific indices",
        default=False
    )
    bpy.types.Armature.disable_location_start = IntProperty(
        name="Start Index", 
        description="Start index (inclusive) for disabling location",
        default=0,
        min=0,
        max=1000
    )
    bpy.types.Armature.disable_location_end = IntProperty(
        name="End Index", 
        description="End index (inclusive) for disabling location",
        default=0,
        min=0,
        max=1000
    )

def unregister():
    # Сначала удаляем из меню
    bpy.types.TOPBAR_MT_file_import.remove(replicant_import_motion_pack)
    bpy.types.TOPBAR_MT_file_import.remove(replicant_import_mesh_pack)
    
    # Затем удаляем свойства
    del bpy.types.Armature.motion_mappings
    del bpy.types.Armature.selected_motion
    del bpy.types.Armature.active_mapping_index
    del bpy.types.Armature.transfer_n_all_to_armature
    del bpy.types.Armature.transformation_mode
    del bpy.types.Armature.disable_location_enabled
    del bpy.types.Armature.disable_location_start
    del bpy.types.Armature.disable_location_end
    
    # Удаляем классы в обратном порядке регистрации
    bpy.utils.unregister_class(MOTION_OT_TransferNALLToArmature)
    bpy.utils.unregister_class(MOTION_OT_ApplyMapping)
    bpy.utils.unregister_class(MOTION_OT_ResetMapping)
    bpy.utils.unregister_class(MOTION_OT_ShiftMappingDecrease)
    bpy.utils.unregister_class(MOTION_OT_ShiftMappingIncrease)
    bpy.utils.unregister_class(MOTION_OT_RemoveMapping)
    bpy.utils.unregister_class(MOTION_OT_AddMapping)
    
    bpy.utils.unregister_class(MOTION_PT_MappingPanel)
    
    bpy.utils.unregister_class(REPLICANT_UL_BoneMapping)
    bpy.utils.unregister_class(BoneMapping)
    
    # Импортеры и настройки
    bpy.utils.unregister_class(REPLICANT_PT_AxisSettings)
    bpy.utils.unregister_class(REPLICANT_OT_SetAxisPreset)
    bpy.utils.unregister_class(Replicant2BlenderPreferences)
    bpy.utils.unregister_class(SelectNoesisExecutable)
    bpy.utils.unregister_class(ImportReplicantMotionPack)
    bpy.utils.unregister_class(ImportReplicantMeshPack)
    
    bpy.utils.unregister_class(cmf_export.MOTION_OT_ExportCurrentAnimation)
    bpy.utils.unregister_class(cmf_export.EXPORT_OT_CmfJson)
    bpy.utils.unregister_class(MOTION_OT_LoadMappings)
    bpy.utils.unregister_class(MOTION_OT_SaveMappings)
    bpy.utils.unregister_class(ImportReplicantCMFFile)
    bpy.utils.unregister_class(MOTION_OT_ImportMDVLBones)
    
    bpy.utils.unregister_class(MOTION_OT_FillGaps)

    
    # Удаляем пункт из меню экспорта
    bpy.types.TOPBAR_MT_file_export.remove(cmf_export.menu_export_cmf_json)
    bpy.types.TOPBAR_MT_file_import.remove(replicant_import_cmf_file)


if __name__ == '__main__':
    register()